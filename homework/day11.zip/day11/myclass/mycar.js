
class MyCar{
    model = "porsche"
    horsepower = 400
    color = "Navy"
    constructor(){
        this.model = dreamCar
        this.horsepower = die
        this.color = Sky
    }

    Stop = ()=>{
        console.log(`${dreamCar}도 빨간 불 앞에선 멈춰야지`)
    }

    Boost=()=>{
        console.log(`${die}으로 달려보자!!`)
    }

    Drive=()=>{
        console.log(`${Sky} color is my favorite`)
    }

}
